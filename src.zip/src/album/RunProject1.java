package album;

public class RunProject1 {
    public static void main(String[] args) {
        new CollectionManager().run();
    }
}
